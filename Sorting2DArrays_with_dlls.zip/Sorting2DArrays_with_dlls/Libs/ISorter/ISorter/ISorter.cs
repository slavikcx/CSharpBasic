﻿
namespace Sorters.Common
{
    public interface ISorter
    {
        int[] Sort(bool isDescending);
    }
}

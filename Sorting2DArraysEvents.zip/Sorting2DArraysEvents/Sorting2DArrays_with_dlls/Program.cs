﻿
namespace Sorters
{
   
    class Program
    {
        
        static void Main(string[] args)
        {
            
            Controller controller = new Controller();
            
            controller.Start();
        }
    }
}
